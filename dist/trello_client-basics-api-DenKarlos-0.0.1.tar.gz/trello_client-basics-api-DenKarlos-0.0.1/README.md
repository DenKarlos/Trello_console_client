Это мой консольный клиент для Trello!
This is my console client for Trello!